package com.example.countrydetail;

public class Ind {

  //  String Id;
    String CityName;
    String State;
    String Population;
    String Link;
   // String Lastname;

    public Ind(String Name, String state, String population, String link) {
        this.CityName = Name;
        this.State = state;
        this.Population = population;
        this.Link = link;

    }
    public Ind() {
    }

    public String getName() {
        return CityName;
    }

    public void setName(String Name) {
        CityName = Name;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getPopulation() {
        return Population;
    }

    public void setPopulation(String population) {
        Population = population;
    }



    @Override
    public String toString() {
        return " India_row{ " +
                "CitytName='" + CityName + '\'' +
                ", State='" + State + '\'' +
                ", Population='" + Population + '\'' +
                ", Link='" + Link + '\'' +
              //  ", Mobile_No='" + Mobileno + '\'' +
               // ", Sur_name='" + Lastname + '\'' +
                '}';
    }
}
