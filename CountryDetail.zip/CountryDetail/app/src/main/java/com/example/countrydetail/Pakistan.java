package com.example.countrydetail;

public class Pakistan {
}
