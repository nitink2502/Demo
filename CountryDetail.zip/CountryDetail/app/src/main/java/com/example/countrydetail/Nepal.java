package com.example.countrydetail;

public class Nepal {
}
