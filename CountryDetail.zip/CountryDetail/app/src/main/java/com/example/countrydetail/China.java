package com.example.countrydetail;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

public class China  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.china_city);
        ListView list = findViewById(R.id.list);
        ArrayList<Chi_row> arrayList = new ArrayList<Chi_row>();

        try{
            ChiParseXml parser =new ChiParseXml();
            arrayList = (ArrayList<Chi_row>) parser.parse(getAssets().open("china_city_detail.xml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ChinaCustomAdapter customAdapter = new ChinaCustomAdapter(this, arrayList);
        list.setAdapter(customAdapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }
}
