package com.example.countrydetail;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DetailViewChina extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_china_detail);
        ListView list = findViewById(R.id.list);
        ArrayList<Chi_row> arrayList = new ArrayList<Chi_row>();
        arrayList.add(ChinaCustomAdapter.subjectData);
        DetailCustomAdapterChina customAdapter = new DetailCustomAdapterChina(this, arrayList);
        list.setAdapter(customAdapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
