package com.example.countrydetail;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ChiParseXml {

    public List<Chi_row> cities;
    private Chi_row city;
    private String text;
    public ChiParseXml(){
        cities=new ArrayList<Chi_row>();
    }
    public List<Chi_row> getEmployees() {
        return cities;
    }
    public List<Chi_row> parse(InputStream is){
        XmlPullParserFactory factory=null;                   //This class is used to create implementations of XML Pull Parser.
        XmlPullParser parser = null;
        try {
            factory=XmlPullParserFactory.newInstance();    //Creates a new instance of a PullParserFactory that can be used to create XML pull parsers.
            factory.setNamespaceAware(true);              //Specifies that the parser produced by this factory will provide support for XML namespaces.
            parser=factory.newPullParser();              //Creates a new instance of a XML Pull Parser using the currently configured factory features.
            parser.setInput(is,null);
            int eventType= parser.getEventType();        //Returns the type of the current event (START_TAG, END_TAG, TEXT, etc.)
            while(eventType!=XmlPullParser.END_DOCUMENT) {
                String tagname = parser.getName();        //For START_TAG or END_TAG events, the (local) name of the current element is returned when namespaces are enabled.
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if (tagname.equalsIgnoreCase("city")) {
                            city = new Chi_row();
                        }
                        break;
                    case XmlPullParser.TEXT:
                        text = parser.getText();
                        break;
                    case XmlPullParser.END_TAG:
                        if (tagname.equalsIgnoreCase("city")) {
                            //add employee object to list
                            cities.add(city);
                        } else if (tagname.equalsIgnoreCase("name")) {
                            city.setName(text);
                        } else if (tagname.equalsIgnoreCase("image")) {
                            city.setLink(text);
                        } else if (tagname.equalsIgnoreCase("state")) {
                            city.setState(text);
                        }
                        else if (tagname.equalsIgnoreCase("population")) {
                            city.setPopulation(text);
                        }

                        break;
                    default:
                        break;
                }
                eventType = parser.next();
            }
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cities;
    }
}
