package com.example.countrydetail;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DetailView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ind_detail);
        ListView list = findViewById(R.id.list);
        ArrayList<Ind> arrayList = new ArrayList<Ind>();
        arrayList.add(IndiaCustomAdapter.subjectData);
        DetailsCustomAdapter customAdapter = new DetailsCustomAdapter(this, arrayList);
        list.setAdapter(customAdapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
