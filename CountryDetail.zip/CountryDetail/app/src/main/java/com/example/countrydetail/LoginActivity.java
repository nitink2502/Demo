package com.example.countrydetail;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends Activity implements AdapterView.OnItemClickListener {

    ListView listView;
    Button AddButton;
    EditText username;
    EditText password;
    ArrayList<MainPojo> arrayList = new ArrayList<MainPojo>();


    boolean isValidUser=false;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        AddButton = (Button) findViewById(R.id.loginBtn);
        username = (EditText)findViewById(R.id.userName);
        password = findViewById(R.id.password);

        List<MainPojo> employees = null;

        try{
            MainParse parser =new MainParse();
            arrayList = (ArrayList<MainPojo>) parser.parse(getAssets().open("userdetail.xml"));


        } catch (IOException e) {
            e.printStackTrace();
        }
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isValidUser= validate(arrayList,username.getText().toString()
                        ,password.getText().toString());

                if (isValidUser) {
                    Intent myIntent = new Intent(v.getContext(), MainActivity.class);
                    startActivity(myIntent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Wrong user...", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    @Override
    public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
        Toast.makeText(getApplicationContext(), ((TextView) view).getText(),
                Toast.LENGTH_SHORT).show();
    }
    public boolean validate(ArrayList<MainPojo> user, String un, String pwd){
        System.out.println("in valid "+un+pwd);
        for(MainPojo u : user){
            if(u.getName().equals(un) && u.getPassword().equals(pwd))
                return true;
        }
        return false;

    }


}
