package com.example.countrydetail;

public class Chi_row {

    //  String Id;
    String CityName;
    String State;
    String Population;
    String Link;
    // String Lastname;

    public Chi_row(String Name, String state, String population, String link) {
        this.CityName = Name;
        this.State = state;
        this.Population = population;
        this.Link = link;

    }
    public Chi_row() {
    }

    public String getName() {
        return CityName;
    }

    public void setName(String Name) {
        CityName = Name;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getPopulation() {
        return Population;
    }

    public void setPopulation(String population) {
        Population = population;
    }



    @Override
    public String toString() {
        return " China_row{ " +
                "CitytName='" + CityName + '\'' +
                ", State='" + State + '\'' +
                ", Population='" + Population + '\'' +
                ", Link='" + Link + '\'' +
                //  ", Mobile_No='" + Mobileno + '\'' +
                // ", Sur_name='" + Lastname + '\'' +
                '}';
    }
}
