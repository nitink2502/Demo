package com.example.countrydetail;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

public class India extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.india_city);
        ListView list = findViewById(R.id.list);
        ArrayList<Ind> arrayList = new ArrayList<Ind>();

        try{
            IndParseXml parser =new IndParseXml();
            arrayList = (ArrayList<Ind>) parser.parse(getAssets().open("india_city_detail.xml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        IndiaCustomAdapter customAdapter = new IndiaCustomAdapter(this, arrayList);
        list.setAdapter(customAdapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }
}
